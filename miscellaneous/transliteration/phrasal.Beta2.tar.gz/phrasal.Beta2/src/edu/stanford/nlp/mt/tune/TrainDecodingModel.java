package edu.stanford.nlp.mt.tune;

/**
 * 
 * 
 * @author danielcer
 *
 */
public class TrainDecodingModel {
  
}
