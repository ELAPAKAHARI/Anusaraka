package edu.stanford.nlp.mt.base;

/**
 * 
 * @author danielcer
 * 
 */
public interface HasIntegerIdentity {
  int getId();
}
