package edu.stanford.nlp.mt.base;

interface HasAdmissibleFeatureName {
  public String featureName();
}
