package edu.stanford.nlp.mt.metrics;

/**
 * 
 * @author danielcer
 * 
 */
public interface HasSmoothScore {
  double smoothScore();
}
